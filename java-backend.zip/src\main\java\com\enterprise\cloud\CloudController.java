package com.enterprise.cloud;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CloudController {

    @GetMapping("/")
    public String home() {
        return "Welcome to the Java Spring Boot Backend running on Amazon EC2!";
    }

    @GetMapping("/api/status")
    public String getStatus() {
        return "{\"status\": \"UP\", \"cloud\": \"AWS EC2\"}";
    }
}
